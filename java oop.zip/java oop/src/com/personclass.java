package com;

class personclass { //class biasa
                    //clas public
                    //

    
}