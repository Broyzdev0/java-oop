
//super keyworld
package com;

class shape {

    int getCotner(){
        return 0;
    }
    
class Rectangel extends shape {

    int getCotner(){
        return 4;
    }

    int getParentCorner(){
        return super.getCotner();
    }

    
}
}