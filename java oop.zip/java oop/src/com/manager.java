package com;
class manager extends Employee {

    String company;

    manager(String name){
        super(name);
        
    }
    manager(String name, String company){
        super(name);
        this.company = company;
    }
    void sayHello(String name){
        System.out.println("Hi " + name + ", My name is " + this.name);
    }
    
}
