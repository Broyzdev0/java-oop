package com;

public class Rectangel {

}
