package com;

public class parent {
   String name;
   void doIt(){
    System.out.println("Do it in Parent");
   }
}

class Child extends parent{
    String name;
    void doIt(){
        System.out.println("Do it in child");
    }
}
