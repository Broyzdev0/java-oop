package com;
class VicePresident extends manager {
    
    void sayHello(String name){
        System.out.println("Hi " + name + ", My name is vp " + this.name);
    }
}
