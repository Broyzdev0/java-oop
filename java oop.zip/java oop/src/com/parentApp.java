package com;

public class parentApp {

    public static void main(String[] args) {
        
        Child child = new Child();
        child.name = "Eko";
        child.doIt();
        System.out.println(child.name);

        parent parent = (parent) child;
        parent.doIt();
        System.out.println(parent.name);
    }
    
}
