package com;

public class personobject {

    public static void main(String[] args) {
        var person1 = new person("Angga NUR Gunawan", "Subang");


        System.out.println(person1.name);
        System.out.println(person1.address);
        System.out.println(person1.country);

        person1.sayHello("budi");
        
        person person2 = new person("Budi", "Subang");
        person2.sayHello(null);


        person person3;
        person3 = new person();
       person3.name = "Budi";
        person3.sayHello("Budi");

        
    
    }
    
}
