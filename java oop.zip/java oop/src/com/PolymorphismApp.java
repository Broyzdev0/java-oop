package com;

public class PolymorphismApp {
    public static void main(String[] args) {
        
        Employee employee = new Employee ("eko");
        employee.sayHello("budi");

        employee = new manager("Joko");
        employee.sayHello("Budi");

        employee = new VicePresident();
        employee.sayHello("budi");


        sayHello(new Employee("Eko"));
        sayHello(new manager("Joko"));
        sayHello(new VicePresident());

       
    }
    static void sayHello(Employee employee){

        if (employee instanceof VicePresident) {
          VicePresident vicePresident = (VicePresident) employee;  
        System.out.println("Hello vp " + vicePresident.name);
    }else if (employee instanceof manager) {
        manager manager = (manager) employee;
        System.out.println("Hello manager " + manager.name);
    }else{
        System.out.println("Hello " + employee.name);
    }
}
}
