package com;

public class ShapeApp{ 
    public static void main(String[] args) {


        var shape = new shape();
        System.out.println(shape.getCotner());

        var rectangel = new Rectangel();
        System.out.println(rectangel.getCotner());
        System.out.println(rectangel.getParentCotner());
    }
    
}
