package com;

public class managerApp {
    public static void main(String[] args) {
        

        var manager = new manager(null);
        manager.name = "Angga";
        manager.sayHello("Broyz");

        var vp = new VicePresident();
        vp.name = "Haxor";
        vp.sayHello("Broyz");

        System.out.println(manager);
        System.out.println(vp);
      }
    
}
