package com;

//object
class person {
    String name;
    String address;
    final String country = "indonesia";

    //parameter construktor
    person(String name, String addres){
       this. name = name;
        this.address = addres;

    }

    person(String paramName){
        this(paramName, null);
        

    }
    person(){
        this(null);
    }

    //menthod
    void sayHello(String name){ 
        System.out.println("Hello " + name + ", my name is " + this.name);
    }
    
}
